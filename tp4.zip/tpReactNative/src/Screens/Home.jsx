import React from 'react'
import { View } from 'react-native'
import Button from '../components/Button'
import Paragraph from '../components/Paragraph'

export default function Home({ navigation }) {
  return (
    <View>
      <Paragraph>
        ¡Bienvenido!
      </Paragraph>
      <Button
        mode="contained"
        onPress={() => navigation.navigate('Login')}
      >
        Login
      </Button>
    </View>  
  )
}