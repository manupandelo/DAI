import AxiosClient from './axiosClient';
import React, {
  useState,
  useEffect,
  useContext
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const login = async (userState) => {
  console.log(userState);
  return AxiosClient
    .post(`/administradores/logIn`, {
      ...userState
    })
    .then(async(res) => {
      let userToken = res.data.token; // poner punto (nombe que viene del back)
      let userId = res.data.id
      const idValue = JSON.stringify(userId) // lo pasa a string
      await AsyncStorage.setItem('token', userToken) // guarda en el storage con el nombre token 
      await AsyncStorage.setItem('id', idValue) // guarda en el storage con el nombre id
    })
    .catch((e) => {
      console.log(`register error`, e.response);
      throw "error" //propagar error
    });
};

