export function passwordValidator(password) {
    if (!password) return "Password can't be empty."
    return ''
}